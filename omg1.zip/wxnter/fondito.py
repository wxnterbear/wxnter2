import pygame
from pygame.locals import* #importa todas las librerías del módulo pygame
import sys
